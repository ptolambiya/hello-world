from sqlalchemy import create_engine, text, URL, MetaData, Table
from sqlalchemy.exc import SQLAlchemyError
from etl.connections.base_connection import BaseConnection
from sqlalchemy.engine import URL
import json

class DatabaseConnection(BaseConnection):
    DIALECT_MAP = {
        'ORACLE': 'oracle',
        'MSSQL': 'mssql',
        'DB2': 'db2',
        'POSTGRES': 'postgresql'
    }
    
    DRIVER_MAP = {
        'ORACLE': 'cx_oracle',
        'MSSQL': 'pymssql',
        'DB2': 'ibm_db',
        'POSTGRES': 'psycopg2'
    }

    def __init__(self):
        self.engine = None
        self.session = None
        self.system_type = None

    def connect(self, config: dict):
        dialect = self.DIALECT_MAP[self.system_type]
        driver = self.DRIVER_MAP[self.system_type]
        conn_str = self._build_connection_string(dialect, driver, json.loads(config))
        self.engine = create_engine(conn_str)
        self.session = self.engine.connect()

    def _build_connection_string(self, dialect, driver, config):
        if self.system_type == 'ORACLE':
            return f"{dialect}+{driver}://{config['user']}:{config['password']}@" \
                   f"{config['host']}:{config['port']}/?service_name={config['service_name']}"
        elif self.system_type == 'MSSQL':
            return URL.create(
                f"{dialect}+{driver}",
                username=config['user'],
                password=config['password'],
                host=config['host'],
                port=config['port'],
                database=config['database']
            )
        elif self.system_type == 'POSTGRES':
            return f"{dialect}+{driver}://{config['user']}:{config['password']}@" \
                   f"{config['host']}:{config['port']}/{config['database']}"
        elif self.system_type == 'DB2':
            return f"{dialect}+{driver}://{config['user']}:{config['password']}@" \
                   f"{config['host']}:{config['port']}/{config['database']}"

    def extract_data(self, query: str):
        result = self.session.execute(text(query))
        return [row._asdict() for row in result]
        #return result

    def load_data(self, table_name, data):
        if not data:
            return
            
        # Reflect destination table structure
        metadata = MetaData()

        # Reflect the destination table using engine
        with self.engine.connect() as conn:
            metadata.reflect(bind=conn, only=[table_name])
            table = Table(table_name, metadata)
            
            # Get destination column names (case-insensitive)
            dest_columns = {col.name.upper(): col.name for col in table.columns}
            
            # Map source data to destination columns
            mapped_data = []
            for row in data:
                mapped_row = {}
                for src_key, value in row.items():
                    normalized_key = src_key.upper()
                    if normalized_key in dest_columns:
                        dest_col = dest_columns[normalized_key]
                        mapped_row[dest_col] = value
                if mapped_row:
                    mapped_data.append(mapped_row)
            
            if not mapped_data:
                print("No columns matched between source and destination")
                return

            try:
                # Use SQLAlchemy Core for Oracle-optimized bulk insert
                with self.engine.begin() as connection:
                    connection.execute(table.insert(), mapped_data)
                print(f"Successfully inserted {len(mapped_data)} rows into {table_name}")
            except Exception as e:
                print(f"Database insert error: {str(e)}")
                raise

    def truncate_table(self,destination_table:str):
            self.session.execute(text('TRUNCATE TABLE ' + destination_table))

    def close(self):
        if self.session:
            self.session.close()
        if self.engine:
            self.engine.dispose()
