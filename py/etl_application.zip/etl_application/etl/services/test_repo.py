from ..db.base import DBMixin, metadata
from ..repositories.etl_config_repository import ETLConfigRepository
from ..repositories.field_mapping_repository import FieldMappingRepository

# Initialize database connection
db_mixin = DBMixin('oracle+cx_oracle://user:pass@host:1521/?service_name=XE')

# Get session
session = db_mixin.get_local_session()

# Access repositories
config_repo = ETLConfigRepository(session)
mapping_repo = FieldMappingRepository(session)

# Get configuration
config = config_repo.get_by_name('weather_api')

# Get mappings
mappings = mapping_repo.get_by_config(config.id)

# Proper cleanup
db_mixin.shutdown_session(session)
