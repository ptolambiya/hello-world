from sqlalchemy.exc import DatabaseError
from sqlalchemy import datetime
from ..db.base import DBMixin, metadata
from ..repositories import (
    SystemConfigRepository,
    ServiceGroupRepository,
    ServiceDetailRepository,
    ServiceColumnMappingRepository
)
from ..connections import (
    DatabaseConnection, 
    KafkaConnection, APIConnection
)
from ..parsers import JsonParser, XmlParser, CsvParser, TableParser

class ETLService(DBMixin):
    CONNECTION_MAP = {
        'ORACLE': DatabaseConnection,
        'MSSQL': DatabaseConnection,
        'DB2': DatabaseConnection,
        'POSTGRES': DatabaseConnection,
        'API': APIConnection,
        'KAFKA': KafkaConnection
    }
    
    PARSER_MAP = {
        'TABLE': TableParser,
        'JSON': JsonParser,
        'XML': XmlParser,
        'CSV': CsvParser
    }

    def run_etl_group(self, group_name: str):
        local_session = self.get_local_session()
        try:
            group = ServiceGroupRepository(local_session).get_by_name(group_name)
            sys_repo = SystemConfigRepository(local_session)
            
            source_system = sys_repo.get_by_id(group.source_system_id)
            target_system = sys_repo.get_by_id(group.target_system_id)
            
            # Get ordered service details
            details = ServiceDetailRepository(local_session)\
                .get_by_group_ordered(group.id)
            
            for detail in details:
                self._process_detail(
                    local_session,
                    source_system,
                    target_system,
                    detail
                )
                
            group.last_execution = datetime.now()
            local_session.commit()
            
        except Exception as e:
            local_session.rollback()
            raise
        finally:
            local_session.close()

    def _process_detail(self, session, source_system, target_system, detail):
        # Establish connections
        source_conn = self._get_connection(source_system.system_type)
        source_conn.system_type = source_system.system_type
        
        target_conn = self.CONNECTION_MAP[target_system.system_type]()
        try:
            source_conn.connect(source_system.connection_config)
            target_conn.connect(target_system.connection_config)
            
            # Extract data
            if detail.source_type == 'DATABASE':
                raw_data = source_conn.extract_data(detail.extraction_query)
            else:
                raw_data = source_conn.extract_data()

            # Get ordered column mappings
            column_mappings = ServiceColumnMappingRepository(session)\
                .get_by_service_detail(detail.id)
        
            # Transform data
            processed_data = self._transform_data(
                raw_data, 
                detail.source_data_type,
                column_mappings,
                detail.trim_col_list
            )
        
            # Load data
            self._load_data(
                target_conn,
                detail.destination_table,
                processed_data,
                detail.target_truncate
            )
        
        finally:
            source_conn.close()
            target_conn.close()

    def _transform_data(self, raw_data, data_type, mappings, trim_cols):
        # Create parser with ordered mappings
        parser = self.PARSER_MAP.get(data_type, TableParser)(mappings)
        parsed_data = parser.parse(raw_data)
        
        # Apply trimming and other transformations
        transformed_data = []
        for row in parsed_data:
            transformed_row = {}
            for mapping in mappings:
                value = row.get(mapping.source_path)
                
                # Apply data type conversion
                if mapping.data_type:
                    value = self._cast_type(value, mapping.data_type)
                
                # Apply transformation function
                if mapping.transformation:
                    value = self._apply_transformation(value, mapping.transformation)
                
                transformed_row[mapping.destination_column] = value
                
            # Apply column trimming
            if trim_cols:
                transformed_row = {
                    k: v.strip() if k in trim_cols and isinstance(v, str) else v
                    for k, v in transformed_row.items()
                }
            
            transformed_data.append(transformed_row)
        
        return transformed_data

    def _cast_type(self, value, data_type):
        # Implement type casting logic
        try:
            if data_type == 'DATE':
                return datetime.strptime(value, '%Y-%m-%d')
            elif data_type == 'NUMBER':
                return float(value)
            # Add more type conversions as needed
        except:
            return value

    def _apply_transformation(self, value, transformation):
        # Implement transformation functions
        if transformation == 'UPPERCASE':
            return str(value).upper()
        elif transformation == 'TRIM':
            return str(value).strip()
        # Add more transformations as needed
        return value

    def _load_data(self, connection, table_name, data, truncate_flag):
        if truncate_flag == 'Y':
            connection.execute(f"TRUNCATE TABLE {table_name}")
        
        if data:
            connection.load_data(table_name, data)
