# etl_application/services/etl_service.py
from sqlalchemy import Table
from sqlalchemy.exc import DatabaseError
from ..db.base import DBMixin, metadata
from ..repositories import ETLConfigRepository, FieldMappingRepository
from ..connections import DBConnection, JDBCConnection, KafkaConnection, APIConnection
from ..parsers import JsonParser, XmlParser, CsvParser, TableParser

class ETLService(DBMixin):
    CONNECTION_MAP = {
        'DB': DBConnection,
        'JDBC': JDBCConnection,
        'KAFKA': KafkaConnection,
        'API': APIConnection
    }
    
    PARSER_MAP = {
        'TABLE': TableParser,
        'JSON': JsonParser,
        'XML': XmlParser,
        'CSV': CsvParser
    }

    def _get_connection(self, source_type: str):
        return self.CONNECTION_MAP[source_type]()

    def _get_parser(self, data_type: str, mappings: list):
        return self.PARSER_MAP[data_type](mappings)
    
    def run_etl(self, config_name: str):
        local_session = self.get_local_session()
        connection = None
        try:
            config = ETLConfigRepository(local_session).get_by_name(config_name)
            field_mappings = FieldMappingRepository(local_session).get_by_config(config.id)
            
            connection = self._get_connection(config.source_type)
            connection.connect(config.connection_config)
            
            # API sources might not need extraction query
            extraction_query = config.extraction_query if config.source_type in ['DB', 'JDBC'] else None
            raw_data = connection.extract_data(extraction_query)
            
            parser = self._get_parser(config.source_data_type, field_mappings)
            parsed_data = parser.parse(raw_data)
            
            self._load_data(local_session, config.destination_table, parsed_data)
            
        except Exception as e:
            local_session.rollback()
            raise
        finally:
            local_session.close()
            if connection:
                connection.close()

    # def _process_database_data(self, raw_data, field_mappings):
    #     """Process data from database sources with optional field mappings"""
    #     if not field_mappings:
    #         # Automatic column mapping when no mappings exist
    #         return raw_data
        
    #     # Manual mapping when field mappings exist
    #     mapped_data = []
    #     for row in raw_data:
    #         mapped_row = {}
    #         for mapping in field_mappings:
    #             src_value = row.get(mapping['source_path'])
    #             mapped_row[mapping['destination_column']] = src_value
    #         mapped_data.append(mapped_row)
    #     return mapped_data

    # def _process_parsed_data(self, raw_data, data_type, field_mappings):
    #     """Process data from non-database sources using parsers"""
    #     parser = self._get_parser(data_type, field_mappings)
    #     return parser.parse(raw_data)

    def _load_data(self, session, table_name, data):
        metadata.reflect(bind=self.local_engine, only=[table_name])
        table = Table(table_name, metadata, autoload_with=self.local_engine)
        dest_columns = {col.name.upper() for col in table.columns}
        
        mapped_data = []
        for row in data:
            # Handle both automatic and manual mappings
            mapped_row = {
                k.upper(): v for k, v in row.items() 
                if k.upper() in dest_columns
            }
            if mapped_row:
                mapped_data.append(mapped_row)
        
        try:
            # Oracle-optimized batch insert
            if mapped_data:
                session.execute(table.insert().values(mapped_data))
                session.commit()
                print(f"Inserted {len(mapped_data)} rows into {table_name}")
        except DatabaseError as e:
            session.rollback()
            print(f"Oracle load error: {str(e)}")
            raise
