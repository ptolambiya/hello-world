from kafka import KafkaConsumer
import json
from etl.connections.base_connection import BaseConnection

class KafkaConnection(BaseConnection):
    def __init__(self):
        self.consumer = None
        
    def connect(self, config: dict):
        self.consumer = KafkaConsumer(
            config['topic'],
            bootstrap_servers=config['bootstrap_servers'],
            group_id=config['group_id'],
            auto_offset_reset='earliest',
            enable_auto_commit=False
        )
        
    def extract_data(self, timeout_ms: int = 5000):
        messages = []
        raw_messages = self.consumer.poll(timeout_ms=timeout_ms)
        for _, msg_list in raw_messages.items():
            messages.extend([m.value.decode('utf-8') for m in msg_list])
        return messages
    
    def close(self):
        if self.consumer:
            self.consumer.close()
