# etl_application/connections/db_connection.py
from sqlalchemy import create_engine, text, URL
from sqlalchemy.exc import SQLAlchemyError
from etl.connections.base_connection import BaseConnection
from sqlalchemy.engine import URL
import json

class DatabaseConnection(BaseConnection):
    DIALECT_MAP = {
        'ORACLE': 'oracle',
        'MSSQL': 'mssql',
        'DB2': 'db2',
        'POSTGRES': 'postgresql'
    }
    
    DRIVER_MAP = {
        'ORACLE': 'cx_oracle',
        'MSSQL': 'pymssql',
        'DB2': 'ibm_db',
        'POSTGRES': 'psycopg2'
    }

    def __init__(self):
        self.engine = None
        self.session = None
        self.system_type = None

    def connect(self, config: dict):
        dialect = self.DIALECT_MAP[self.system_type]
        driver = self.DRIVER_MAP[self.system_type]
        conn_str = self._build_connection_string(dialect, driver, json.loads(config))
        self.engine = create_engine(conn_str)
        self.session = self.engine.connect()

    def _build_connection_string(self, dialect, driver, config):
        if self.system_type == 'ORACLE':
            return f"{dialect}+{driver}://{config['user']}:{config['password']}@" \
                   f"{config['host']}:{config['port']}/?service_name={config['service_name']}"
        elif self.system_type == 'MSSQL':
            return URL.create(
                f"{dialect}+{driver}",
                username=config['user'],
                password=config['password'],
                host=config['host'],
                port=config['port'],
                database=config['database']
            )
        elif self.system_type == 'POSTGRES':
            return f"{dialect}+{driver}://{config['user']}:{config['password']}@" \
                   f"{config['host']}:{config['port']}/{config['database']}"
        elif self.system_type == 'DB2':
            return f"{dialect}+{driver}://{config['user']}:{config['password']}@" \
                   f"{config['host']}:{config['port']}/{config['database']}"

    def extract_data(self, query: str):
        result = self.session.query(query)
        return [dict(row) for row in result]
    
    def close(self):
        if self.session:
            self.session.close()
            
    def close(self):
        if self.session:
            self.session.close()
        if self.engine:
            self.engine.dispose()
